# CosmWasm Schema Derive Macros

[![cosmwasm-schema-derive on crates.io](https://img.shields.io/crates/v/cosmwasm-schema-derive.svg)](https://crates.io/crates/cosmwasm-schema-derive)

This is where all macros related to the
[`cosmwasm-schema`](https://crates.io/crates/cosmwasm-schema) crate live. You
almost certainly don't want to add this crate as an explicit dependency in your
project, but rather import the macros through `cosmwasm-schema`.

## License

This package is part of the cosmwasm repository, licensed under the Apache
License 2.0 (see [NOTICE](https://github.com/CosmWasm/cosmwasm/blob/main/NOTICE)
and [LICENSE](https://github.com/CosmWasm/cosmwasm/blob/main/LICENSE)).
