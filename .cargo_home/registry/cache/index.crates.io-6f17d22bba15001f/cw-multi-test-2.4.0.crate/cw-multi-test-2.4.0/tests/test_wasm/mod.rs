mod test_with_addr_gen;
#[cfg(feature = "cosmwasm_1_2")]
mod test_with_checksum_gen;
