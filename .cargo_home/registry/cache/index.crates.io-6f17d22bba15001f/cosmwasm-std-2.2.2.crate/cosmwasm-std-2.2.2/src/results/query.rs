pub type QueryResponse = crate::Binary;
