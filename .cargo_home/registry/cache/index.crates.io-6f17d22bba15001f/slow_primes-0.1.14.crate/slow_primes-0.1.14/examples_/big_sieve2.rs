extern crate slow_primes;

use std::os;

fn main() {
    let args = os::args();
    let max = args.as_slice()
        .get(1).and_then(|s| from_str(s.as_slice()))
        .unwrap_or(1_000_000);

    let mut sieve = slow_primes::Sieve::new(max);
    while sieve.next().is_some() {}
    if args.as_slice().get(2).is_some() {
        //println!("{} primes below {}", sieve.primes().count(), max);
    }
}
