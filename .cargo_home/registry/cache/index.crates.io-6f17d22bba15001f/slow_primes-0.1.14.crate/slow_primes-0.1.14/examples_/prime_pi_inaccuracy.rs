extern crate slow_primes;

use std::os;

fn main() {
    let max = os::args().as_slice()
        .get(1).and_then(|s| from_str(s.as_slice()))
        .unwrap_or(1_000_000);

    let sieve = slow_primes::Primes::sieve(max);

    let mut last = 0;

    for (i, p) in sieve.primes().enumerate() {
        for x in range(last, p) {
            let (lo, hi) = slow_primes::estimate_prime_pi(x as u64);

            println!("{},{},{}", lo, i, hi);
        }

        last = p;
    }
}
