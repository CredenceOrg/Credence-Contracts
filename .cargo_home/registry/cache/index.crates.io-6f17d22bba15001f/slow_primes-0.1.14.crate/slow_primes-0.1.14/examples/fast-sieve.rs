extern crate slow_primes;

use slow_primes::StreamingSieve;

const LIMIT: usize = 16 * (32 << 10) * 200;
fn main() {
    let l = LIMIT;
    let mut streaming = StreamingSieve::new(l);
    let mut total = 1;
    while let Some((low, next)) = streaming.next() {
        let count = next.iter().take((l - low) / 2).filter(|&b| b).count();
        total += count;
    }
    println!("{} primes below {}", total, l);
}
