# test_wasms

Files contained in this directory are used in a few SDK tests that are sensitive
to Wasm content changes.

`test_contract_data.wasm` is a build of `tests/contract_data`  test contract.
