# Smart Punctuation

- En dash: --
- Em dash: ---
- Ellipsis: ...
- Double quote: "quote"
- Single quote: 'quote'
