# Passing Tests 2

```rust
println!("also passing");
```
