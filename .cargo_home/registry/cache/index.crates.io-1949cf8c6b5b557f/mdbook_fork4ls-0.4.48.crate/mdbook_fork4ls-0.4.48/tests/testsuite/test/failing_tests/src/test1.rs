fn test2() {
    println!("test2");
}

// ANCHOR: PASSING
println!("passing!");
// ANCHOR_END: PASSING

// ANCHOR: FAILING
panic!("failing!");
// ANCHOR_END: FAILING
