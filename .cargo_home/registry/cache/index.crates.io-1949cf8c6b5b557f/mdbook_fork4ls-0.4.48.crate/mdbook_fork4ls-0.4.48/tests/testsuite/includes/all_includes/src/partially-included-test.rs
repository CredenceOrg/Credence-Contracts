fn some_function() {
    println!("some function");
}

fn main() {
    some_function();
}
