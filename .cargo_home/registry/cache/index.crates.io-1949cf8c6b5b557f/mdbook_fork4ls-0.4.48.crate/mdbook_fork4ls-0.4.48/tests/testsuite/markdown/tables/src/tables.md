# Tables

| foo | bar |
| --- | --- |
| baz | bim |
| Backslash in code | `\` |
| Double back in code | `\\` |
| Pipe in code | `\|` |
| Pipe in code2 | `test \| inside` |
