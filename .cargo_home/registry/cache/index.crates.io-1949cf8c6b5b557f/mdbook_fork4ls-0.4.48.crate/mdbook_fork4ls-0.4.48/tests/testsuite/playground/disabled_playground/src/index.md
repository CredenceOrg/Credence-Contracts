# Rust Sample

```rust
let x = 1;
```
