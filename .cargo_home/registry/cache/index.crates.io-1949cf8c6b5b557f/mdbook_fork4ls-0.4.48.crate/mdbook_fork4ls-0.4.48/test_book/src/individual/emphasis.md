# Emphasis

This has **bold text** in between normal.

This has _italic text_ in between normal.

A **line** having _both_, bold and italic text.

**A bold line _having_ italic text**

_An Italic line having **bold** text_

Now this is going **_out of hands_**.
