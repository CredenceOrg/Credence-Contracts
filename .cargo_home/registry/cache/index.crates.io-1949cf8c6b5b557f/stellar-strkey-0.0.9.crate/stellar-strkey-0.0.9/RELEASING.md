# Releasing

The process for how to release the crates in this repository are documented here:

https://github.com/stellar/actions/blob/main/README-rust-release.md
