use version_sync::assert_markdown_deps_updated;

fn main() {
    assert_markdown_deps_updated!("README.md");
}
