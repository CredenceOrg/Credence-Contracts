//! Module contains iterator specific trait implementations.

use super::U256;

impl_iter! {
    impl Iter for U256;
}
