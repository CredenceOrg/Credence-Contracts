# Syntax Highlighting

This GUI test book is used for testing syntax highlighting.
