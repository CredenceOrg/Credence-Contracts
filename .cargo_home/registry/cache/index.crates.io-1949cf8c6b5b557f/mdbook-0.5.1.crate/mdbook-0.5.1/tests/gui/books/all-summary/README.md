# All summary

This GUI test book tests all the different kinds of book items in the summary.
