# Normal text before first heading

This test is to ensure the first heading shows up as "current" on page load.

## The first heading

1

2

3

## The second heading

### And a sub heading
