# Current scrolls to bottom

Checks that the "current" header works even when there are headers near the bottom.

## First header

<span id="scroll-to-1">1</span>\
<span id="scroll-to-2">2</span>\
<span id="scroll-to-3">3</span>\
<span id="scroll-to-4">4</span>\
<span id="scroll-to-5">5</span>\
<span id="scroll-to-6">6</span>\
<span id="scroll-to-7">7</span>\
<span id="scroll-to-8">8</span>\
<span id="scroll-to-9">9</span>\
<span id="scroll-to-10">10</span>\
<span id="scroll-to-11">11</span>\
<span id="scroll-to-12">12</span>\
<span id="scroll-to-13">13</span>\
<span id="scroll-to-14">14</span>\
<span id="scroll-to-15">15</span>\
<span id="scroll-to-16">16</span>\
<span id="scroll-to-17">17</span>\
<span id="scroll-to-18">18</span>\
<span id="scroll-to-19">19</span>\
<span id="scroll-to-20">20</span>

## Second header

<span id="scroll-to-21">21</span>

### Second sub-header

<span id="scroll-to-22">22</span>

## Third header

<span id="scroll-to-23">23</span>

## Fourth header

<span id="scroll-to-24">24</span>

## Fifth header

<span id="scroll-to-25">25</span>
