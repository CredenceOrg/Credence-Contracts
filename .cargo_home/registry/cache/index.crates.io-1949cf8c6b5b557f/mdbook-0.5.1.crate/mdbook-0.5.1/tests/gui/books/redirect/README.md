# Redirect

This GUI test book tests the redirect configuration.
