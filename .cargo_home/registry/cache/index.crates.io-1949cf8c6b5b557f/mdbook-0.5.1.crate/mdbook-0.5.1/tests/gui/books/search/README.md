# Search

This GUI test book is used for testing basic search interaction.
