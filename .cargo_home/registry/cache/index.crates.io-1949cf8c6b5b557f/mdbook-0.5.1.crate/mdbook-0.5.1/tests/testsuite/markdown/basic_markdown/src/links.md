# Links

- [Inline](https://example.com/inline)
- [Collapsed]
- [Emtpy reference][]
- [Specific reference][specific]
- <https://example.com/>
- <john@example.com>
- [Titled](https://example.com/title "with title")
- [Broken collapsed]
- [Broken reference][missing]
- [Markdown link](path/foo.md)
- [Markdown link anchor](path/foo.md#anchor)
- [Link anchor](#anchor)
- [With md in anchor](path.html#phantomdata)

[collapsed]: https://example.com/collapsed
[specific]: https://example.com/specific
