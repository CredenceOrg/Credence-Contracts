# Chapter 2

## Some title

See [other](chapter_1.md#some-title)

See [this](chapter_2.md#some-title)

See [this anchor only](#some-title)

[Works with HTML extension too](chapter_1.html#some-title)
