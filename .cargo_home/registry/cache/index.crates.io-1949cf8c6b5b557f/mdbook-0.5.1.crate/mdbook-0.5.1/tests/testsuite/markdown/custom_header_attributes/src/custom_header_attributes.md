# Heading Attributes {#attrs}

## Heading with classes {.class1 .class2}

## Heading with id and classes {#both .class1 .class2}

## Heading with attribute {.myclass1 myattr #myh3 otherattr=value .myclass2}
