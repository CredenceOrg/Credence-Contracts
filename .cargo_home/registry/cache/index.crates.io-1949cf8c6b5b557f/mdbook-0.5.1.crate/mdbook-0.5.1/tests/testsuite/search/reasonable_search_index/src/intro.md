# Introduction

Here's some interesting text...

## Sneaky

<p>
<!--secret secret-->
I put &lt;HTML&gt; in here!<br/>
</p>
<script type="text/javascript" >
// I probably shouldn't do this
if (3 < 5 > 10)
{
    alert("The sky is falling!");
}
</script >
<style >
/*
css looks, like this {
    foo: < 3 <bar >
}
*/
</style>

Sneaky inline event <script>alert("inline");</script>.

But regular <b>inline</b> is indexed.
