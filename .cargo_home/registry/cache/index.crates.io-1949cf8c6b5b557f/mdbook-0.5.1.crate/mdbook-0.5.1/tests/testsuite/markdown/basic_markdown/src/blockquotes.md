# Blockquotes

Empty:
>

Normal:
> foo
> bar

Contains code block:
> ```rust
> let x = 1;
> ```

Random stuff:
> ### And now,
>
> **Let us _introduce_**
> All kinds of
>
> - tags
> - etc
> - stuff
>
> 1. In
> 2. The
> 3. blockquote
>
>    > cause we can
>    >
>    > > Cause we can
