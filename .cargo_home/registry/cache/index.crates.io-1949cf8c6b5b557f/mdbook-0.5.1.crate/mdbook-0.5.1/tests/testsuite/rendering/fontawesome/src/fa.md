# Chapter 1

<i id="example1" class="fas fa-heart extra-class"></i>

<i class="fa fa-user"></i>

<i class="fab fa-font-awesome"></i>

<i class="fas fa-heart">Text prevents translation.</i>

<i class="fa fa-does-not-exist"></i>

<i class="fa-solid fa-cat"></i>
