# Definition Lists

apple
:   red fruit

orange
:   orange fruit

apple
:   red fruit
:   computer company

orange
:   orange fruit
:   telecom company

term
:   1. Para one

       Para two

## Term with link

[apple](some-page.md#apple)
  : red fruit

## Multi-line term

a
b\
c

:   foo

## Nested

level one
: l1
    level two
    : l2
        level three
        : l3

level one
: l1

## Loose

apple

:   red fruit
:   computer company

orange

:   orange fruit
