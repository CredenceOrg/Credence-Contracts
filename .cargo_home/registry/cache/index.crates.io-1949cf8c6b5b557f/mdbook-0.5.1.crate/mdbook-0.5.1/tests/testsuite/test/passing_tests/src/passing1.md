# Passing Tests 1

```rust
assert!(true);
```

```rust
println!("hello!");
```

## Also check includes

```rust
{{#include test1.rs}}
```

```rust
{{#include test2.rs:2}}
```

```rust
{{#include test2.rs:PASSING}}
```

```rust
{{#rustdoc_include test3.rs:2}}
```

{{#playground test1.rs}}
