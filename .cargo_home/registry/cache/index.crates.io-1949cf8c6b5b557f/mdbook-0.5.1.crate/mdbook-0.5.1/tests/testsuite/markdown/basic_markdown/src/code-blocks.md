# Code blocks

```
This is a codeblock
```

```rust
// This links to a playpen
```

```bash,editable
# This is an editable codeblock
```

```text cls1,,cls2	cls3
Text with different classes.
```

    Indented
    code
    block.

```rust,edition2021
let x = 1;
```

```rust
fn main() {
    println!("hello");
}
```
