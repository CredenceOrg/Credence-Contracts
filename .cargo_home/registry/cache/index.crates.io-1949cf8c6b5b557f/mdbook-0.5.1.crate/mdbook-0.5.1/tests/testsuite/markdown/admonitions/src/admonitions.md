# Admonitions

> [!NOTE]
> This is a note.
>
> There are multiple paragraphs.

> [!TIP]
> This is a tip.

> [!IMPORTANT]
> This is important.

> [!WARNING]
> This is a warning.

> [!CAUTION]
> This is a caution.

> [!UNKNOWN]
> This is an unknown tag.
