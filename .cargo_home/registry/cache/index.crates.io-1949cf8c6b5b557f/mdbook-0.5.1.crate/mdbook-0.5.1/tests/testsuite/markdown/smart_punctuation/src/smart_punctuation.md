# Smart Punctuation

- En dash: --
- Em dash: ---
- Ellipsis: ...
- Double quote: "quote"
- Single quote: 'quote'
- Quote in `"code"`

```
"quoted"
```
