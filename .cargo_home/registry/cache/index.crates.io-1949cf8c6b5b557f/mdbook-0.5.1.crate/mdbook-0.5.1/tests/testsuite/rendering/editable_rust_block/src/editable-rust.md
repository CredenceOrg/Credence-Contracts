# Chapter 1

```rust,editable
fn f() {
    println!("hello");
}
```

```rust
// Not editable.
```
