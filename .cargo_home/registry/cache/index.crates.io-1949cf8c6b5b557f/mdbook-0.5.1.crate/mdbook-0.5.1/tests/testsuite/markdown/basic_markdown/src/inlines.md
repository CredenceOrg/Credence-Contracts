# Inlines

*emphasis* **bold** **_bold emphasis_**

Some `inline code`.

Hard\
break

Invisible hard  
break

\[escaped] \<html> \*here*
