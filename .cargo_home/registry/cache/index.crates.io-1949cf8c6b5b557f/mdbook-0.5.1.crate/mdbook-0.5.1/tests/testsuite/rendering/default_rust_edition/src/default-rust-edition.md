# Chapter 1

```rust
let x = 2021;
```

```rust,edition2021
let x = 2021;
```

```rust,edition2024
let x = 2024;
```
