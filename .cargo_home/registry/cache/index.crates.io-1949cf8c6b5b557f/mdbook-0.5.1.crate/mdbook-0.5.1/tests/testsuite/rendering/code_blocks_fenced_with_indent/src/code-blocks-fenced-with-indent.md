# Code blocks fenced with indent

```rust
    // This has a first line that is indented.
    println!("hello");
```
