// This is a test of includes with anchors.

// ANCHOR: myanchor
// ANCHOR: unendinganchor
let x = 1;
// ANCHOR_END: myanchor
