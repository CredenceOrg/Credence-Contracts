# HTML definition lists

Test for definition lists manually written in HTML.

<dl>
    <dt>Some tag</dt>
    <dd>Some defintion</dd>
    <dt class="myclass" id="myid"><a class="option-anchor" href="#foo">Another definition</a></dt>
    <dd class="def-class">A definition.</dd>
</dl>
