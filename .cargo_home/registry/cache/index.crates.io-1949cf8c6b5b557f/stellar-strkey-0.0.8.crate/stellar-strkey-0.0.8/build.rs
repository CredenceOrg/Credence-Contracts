pub fn main() {
    crate_git_revision::init();
}
