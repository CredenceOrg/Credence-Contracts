Workflows adapted from https://github.com/jonhoo/rust-ci-conf.
