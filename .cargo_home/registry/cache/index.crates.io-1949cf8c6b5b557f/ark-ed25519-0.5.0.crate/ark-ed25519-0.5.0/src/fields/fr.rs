pub use ark_curve25519::{Fr, FrConfig};
