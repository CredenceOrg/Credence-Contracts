use crate::*;
use ark_algebra_test_templates::*;

test_group!(te; EdwardsProjective; te);
