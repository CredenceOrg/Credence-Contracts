# doctest_fixtures

Files contained in this directory are used within examples inside docs, i.e.
doctests.

`contract.wasm` is a copy of `test_add_u64`  test contract.

`contract_with_constructor.wasm` is a copy of `test_constructor` test contract.
