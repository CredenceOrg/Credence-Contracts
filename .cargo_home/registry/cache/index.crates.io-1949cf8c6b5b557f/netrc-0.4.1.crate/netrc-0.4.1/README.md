Netrc Parser for Rust
=====================

[![Crates.io](https://img.shields.io/crates/v/netrc.svg)](https://crates.io/crates/netrc)
[![Build Status](https://travis-ci.org/Yuhta/netrc-rs.svg?branch=master)](https://travis-ci.org/Yuhta/netrc-rs)

## [Documentation](http://yuhta.github.io/netrc-rs/doc/netrc/index.html)
