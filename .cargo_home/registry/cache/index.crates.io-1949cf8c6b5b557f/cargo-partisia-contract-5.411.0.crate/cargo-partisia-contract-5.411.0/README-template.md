# Cargo `partisia-contract`

Compiles Smart Contracts for the Partisia Blockchain for deployment on-chain.

## Installation

You can either install from the [crate]() on crates.io, or from source.

### From Crates.io

To install run the command

```bash
cargo install cargo-partisia-contract
```

### Install from source

Clone the repository and go to the folder. Run the following command

```bash
cargo install --path .
```

## Usage

Compiles Smart Contracts for the Partisia Blockchain for deployment on-chain.

<!-- {{{ cargo pbc --help }}} -->

### `build`

Compile a smart contract for deployment on Partisia Blockchain.

<!-- {{{ cargo pbc build --help }}} -->

### `init`

Initialize the contract. Retrieves dependencies for build.

<!-- {{{ cargo pbc init --help }}} -->

### `print-version`

Create a new smart contract project.

<!-- {{{ cargo pbc print-version --help }}} -->

### `path-of-abi`

Print the expected ABI file path based on the context of Cargo.toml

<!-- {{{ cargo pbc path-of-abi --help }}} -->

### `path-of-wasm`

Print the expected WASM file path based on the context of Cargo.toml

<!-- {{{ cargo pbc path-of-wasm --help }}} -->

### `set-sdk`

Update the sdk used for compiling the contracts.

<!-- {{{ cargo pbc set-sdk --help }}} -->


### `transaction`

<!-- {{{ cargo pbc transaction --help }}} -->

### `account`

<!-- {{{ cargo pbc account --help }}} -->

### `contract`

<!-- {{{ cargo pbc contract --help }}} -->

### `config`

<!-- {{{ cargo pbc config --help }}} -->

### `block`

<!-- {{{ cargo pbc block --help }}} -->

### `wallet`

<!-- {{{ cargo pbc wallet --help }}} -->

### `abi`

<!-- {{{ cargo pbc abi --help }}} -->

## How to use

Go into the rust project containing your Cargo.toml and the contract.

An example for a contract written in rust can be found [here](https://partisiablockchain.gitlab.io/documentation/programmers_guide.html).

When you are standing in the directory, run the following command to compile the contract and generate the ABI.

```bash
cargo partisia-contract build --release
```

This will build and write the contract and ABI files in the `target/wasm32-unknown-unknown/debug`.

If you run it with the flag `--release`, then the files will be in `target/wasm32-unknown-unknown/release`.
