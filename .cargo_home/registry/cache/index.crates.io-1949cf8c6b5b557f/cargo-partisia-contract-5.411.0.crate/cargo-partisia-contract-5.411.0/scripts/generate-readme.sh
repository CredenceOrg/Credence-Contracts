#!/usr/bin/env bash
set -eo pipefail

# Generates a temporary readme from the template file
function generate_temp() {
  # Compile the current package
  cargo build
  cp README-template.md README_.md
  # Extract and the commands and substitute them with their output
  COMMANDS="$(sed -n 's/<!\-\- {{{ cargo \(pbc \([a-z]\+\(\-[a-z]\+\)* \)\?\-\-help\)\+ }}} \-\->/\1/p' README_.md)"
  while IFS= read -r line; do
    OUTPUT="./target/debug/cargo-pbc $line"
    OUTPUT_ESC_NEWLINES="$($OUTPUT | awk '{printf "%s\\n", $0}')"
    OUTPUT_ESC_SLASH="$(echo "$OUTPUT_ESC_NEWLINES" | awk '{gsub("/", "\\/"); print}')"
    OUTPUT_REMOVE_COLOR="$(echo "$OUTPUT_ESC_SLASH" | sed -r "s/\x1B\[([0-9]{1,3}(;[0-9]{1,2};?)?)?[mGK]//g")"
    sed -r -i -e "s/<!-- \{\{\{ cargo $line \}\}\} -->/\`\`\`text\\n$OUTPUT_REMOVE_COLOR\`\`\`/" README_.md
  done <<< "$COMMANDS"
}

# Prints the script usage
function print_usage() {
  echo "Usage: ${0##*/} (--generate | --check)"
  echo "   --generate         Generate a new README.md"
  echo "   --check            Check if the README.md is up-to-date or needs to be regenerated."
  exit 1
}

# Print usage if the script is called with no params
if [[ "$#" -ne 1 ]]; then
  print_usage
fi

# Regenerate the README.md or check if it is up-to-date
if [[ "$1" == "--generate" ]]; then
  generate_temp
  cp README_.md README.md
  rm README_.md
  echo "Regenerated the README.md."
elif [[ "$1" == "--check" ]]; then
  generate_temp
  # Find the difference between the current and the regenerated temporary README
  DIFF="$(diff -u README.md README_.md || true)"
  rm README_.md
  if [[ "$DIFF" == "" ]]; then
    echo "README.md is up-to-date."
  else
    echo "README.md needs to be regenerated!"
    echo "Run ${0##*/} --generate to regenerate."
    echo "Found the following differences:"
    echo "$DIFF"
    exit 1
  fi
else
  # Print the usage if the given argument is invalid
  echo "Invalid option ${1}."
  print_usage
fi
