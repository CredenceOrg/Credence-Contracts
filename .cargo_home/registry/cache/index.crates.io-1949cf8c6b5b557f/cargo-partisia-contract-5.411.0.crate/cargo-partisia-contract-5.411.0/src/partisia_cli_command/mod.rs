/// Module for handling partisia cli commands: Transaction, account, contract.
pub(crate) mod partisia_cli;
