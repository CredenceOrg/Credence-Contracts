# Change Log

All notable changes to this project will be documented in this file. The format
is based on [Keep a Changelog](http://keepachangelog.com/).

## [0.1.3] - 2023-07-24

### Fixed

- Bumped walkdir dependency to most recent version.
- Removed uses of deprecated `try!` macro to banish warnings.

## [0.1.2] - 2016-10-31

### Fixed

- Now we return an error if user attempts to copy a directory into itself.
  This should eventually be supported, but a good solution will require
  significant thought and rework.

## [0.1.1] - 2016-10-29

### Fixed

- Totally wrong description in `Cargo.toml`

[0.1.3]: https://github.com/mdunsmuir/copy_dir/compare/0.1.2...0.1.3
[0.1.2]: https://github.com/mdunsmuir/copy_dir/compare/0.1.1...0.1.2
[0.1.1]: https://github.com/mdunsmuir/copy_dir/compare/0.1.0...0.1.1
