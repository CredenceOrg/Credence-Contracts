# doctest_fixtures

Files contained in this directory are used within examples inside docs, i.e.
doctests.
