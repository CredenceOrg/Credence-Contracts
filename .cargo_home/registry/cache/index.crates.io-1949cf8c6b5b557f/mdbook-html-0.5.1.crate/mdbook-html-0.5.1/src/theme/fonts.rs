pub(crate) static CSS: &[u8] = include_bytes!("../../front-end/fonts/fonts.css");
// An array of (file_name, file_contents) pairs
pub(crate) static LICENSES: [(&str, &[u8]); 2] = [
    (
        "fonts/OPEN-SANS-LICENSE.txt",
        include_bytes!("../../front-end/fonts/OPEN-SANS-LICENSE.txt"),
    ),
    (
        "fonts/SOURCE-CODE-PRO-LICENSE.txt",
        include_bytes!("../../front-end/fonts/SOURCE-CODE-PRO-LICENSE.txt"),
    ),
];
// An array of (file_name, file_contents) pairs
pub(crate) static OPEN_SANS: [(&str, &[u8]); 10] = [
    (
        "fonts/open-sans-v17-all-charsets-300.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-300.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-300italic.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-300italic.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-regular.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-regular.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-italic.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-italic.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-600.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-600.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-600italic.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-600italic.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-700.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-700.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-700italic.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-700italic.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-800.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-800.woff2"),
    ),
    (
        "fonts/open-sans-v17-all-charsets-800italic.woff2",
        include_bytes!("../../front-end/fonts/open-sans-v17-all-charsets-800italic.woff2"),
    ),
];

// A (file_name, file_contents) pair
pub(crate) static SOURCE_CODE_PRO: (&str, &[u8]) = (
    "fonts/source-code-pro-v11-all-charsets-500.woff2",
    include_bytes!("../../front-end/fonts/source-code-pro-v11-all-charsets-500.woff2"),
);
