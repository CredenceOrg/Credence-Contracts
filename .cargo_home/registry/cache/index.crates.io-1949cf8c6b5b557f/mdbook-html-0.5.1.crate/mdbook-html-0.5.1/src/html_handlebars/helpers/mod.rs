pub(crate) mod fontawesome;
pub(crate) mod resources;
pub(crate) mod toc;
