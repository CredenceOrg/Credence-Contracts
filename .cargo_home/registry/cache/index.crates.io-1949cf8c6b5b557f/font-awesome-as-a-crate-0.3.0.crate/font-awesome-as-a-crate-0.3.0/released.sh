#!/bin/sh
echo "This script only makes sense on a source code checkout from version control."
echo "It does nothing on a crates.io release."
