# [Font Awesome Free](https://fontawesome.com/download) SVG files as a crate

This is not officially supported by Fonticons, Inc.
If you have problems, [contact us](https://github.com/rust-lang/docs.rs), not them.

