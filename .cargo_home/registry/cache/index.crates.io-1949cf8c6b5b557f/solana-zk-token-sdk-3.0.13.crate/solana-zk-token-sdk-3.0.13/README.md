# zk-token-sdk (DEPRECATED)

**This crate is deprecated and no longer maintained.**

This crate has been replaced by the [zk-sdk](https://github.com/solana-program/zk-elgamal-proof) crate.

For the latest updates and features, please use the new crate.
