# thin-client
This crate for `thin-client` is deprecated as of v2.0.0. It will receive no bugfixes or updates.

Please use `tpu-client` or `rpc-client`.