#[cfg(feature = "compat-0_14")]
mod generic_array_0_14;

#[cfg(feature = "hybrid-array-0_4")]
mod hybrid_array_0_4;
