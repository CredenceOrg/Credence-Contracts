if ("object" == typeof exports && "object" == typeof module) {
    var __old_exports = exports;
    var __old_module = module;
    exports = undefined;
    module = undefined;
}
