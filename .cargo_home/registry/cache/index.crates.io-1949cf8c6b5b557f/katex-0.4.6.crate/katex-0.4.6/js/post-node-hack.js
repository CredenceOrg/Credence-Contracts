if ("object" == typeof __old_exports && "object" == typeof __old_module) {
    exports = __old_exports;
    module = __old_module;
    __old_exports = undefined;
    __old_module = undefined;
}
