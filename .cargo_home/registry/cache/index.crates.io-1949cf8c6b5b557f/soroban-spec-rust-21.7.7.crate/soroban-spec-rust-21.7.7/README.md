# rs-soroban-sdk
Rust SDK for writing contracts for [Soroban].

Soroban: https://soroban.stellar.org

Docs: https://docs.rs/soroban-sdk

[Soroban]: https://soroban.stellar.org

## Contributing

Contributing to the SDK? Read [CONTRIBUTING.md](CONTRIBUTING.md).
