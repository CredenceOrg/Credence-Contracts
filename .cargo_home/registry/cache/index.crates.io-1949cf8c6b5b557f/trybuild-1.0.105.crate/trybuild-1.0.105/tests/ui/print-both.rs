fn main() {
    println!("{:?}", "STDOUT".chars());
    eprintln!("{:?}", "STDERR".chars());
}
