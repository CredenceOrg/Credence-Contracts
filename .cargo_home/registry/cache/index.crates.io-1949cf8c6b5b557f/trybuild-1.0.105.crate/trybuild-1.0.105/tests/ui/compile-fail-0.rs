compile_error!("ERROR");

fn main() {}
