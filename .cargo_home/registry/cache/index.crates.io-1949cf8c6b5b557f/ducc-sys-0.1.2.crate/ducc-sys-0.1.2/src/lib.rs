#![allow(non_snake_case, non_camel_case_types)]

include!("bindings.rs");
